from agents.temp_alert import agent as temp_alert_agent
from messages import TempRequest, UAgentResponse
from uagents import Context



def get_location_input():
    city = input("Enter city: ")
    # mintemp1 = float(input("Enter min temp: "))
    # maxtemp1 = float(input("Enter max temp: "))
    return city

def get_temp_input():
    # lat1 = float(input("Enter latitude: "))
    # long1 = float(input("Enter longitude: "))
    mintemp1 = float(input("Enter min temp: "))
    maxtemp1 = float(input("Enter max temp: "))
    return mintemp1, maxtemp1


@temp_alert_agent.on_interval(period=10.0, messages=TempRequest)
async def interval(ctx: Context):
    started = ctx.storage.get("started")
    if not started:
        city= get_location_input()
        request = TempRequest(city = city)
        await ctx.send(temp_alert_agent.address, request)
    ctx.storage.set("started", True)


@temp_alert_agent.on_message(model=UAgentResponse)
async def fin_output(ctx: Context, sender: str, msg: UAgentResponse):
    mintemp1, maxtemp1 = get_temp_input()
    ctx.logger.info(f"{msg.mytemp}")
    currenttemp = float(msg.mytemp)
    if (currenttemp> maxtemp1 or currenttemp<mintemp1):
        print("temp not b\w min and max")
    else:
        print('temp b\w min and max')


if __name__ == "__main__":
    temp_alert_agent.run()