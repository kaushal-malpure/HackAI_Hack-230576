import os
import uuid
import json
import requests
from messages import TempRequest, KeyValue, UAgentResponse, UAgentResponseType
from uagents import Agent, Context, Protocol
from uagents.setup import fund_agent_if_low

TEMP_SEED = os.getenv("TEMP_SEED", "temp service secret phrase")

agent = Agent(
    name="temp_checker",
    seed=TEMP_SEED,
)

fund_agent_if_low(agent.wallet.address())

WEATHERAPI_API_KEY = os.environ.get("WEATHERAPI_API_KEY", "51ae0da6e49e4fc78c8135128231010")

assert (
    WEATHERAPI_API_KEY
), "WEATHERAPI_API_KEY environment variable is missing from .env"

WEATHERAPI_API_URL = "http://api.weatherapi.com/v1/current.json?"


def get_temp(city: str) -> list:
    """Return ev chargers available within given miles_readius of the latiture and longitude.
    this information is being retrieved from https://api.openchargemap.io/v3/poi? API
    """
    response = requests.get(
        url=WEATHERAPI_API_URL
        + f"key={WEATHERAPI_API_KEY}&q={city}",
        headers={"x-api-key": WEATHERAPI_API_KEY},
        timeout=5,
    )
    if response.status_code == 200:
        return response.json()
    return []


temp_check_protocol = Protocol("TempCheck")


@temp_check_protocol.on_message(model=TempRequest, replies=UAgentResponse)
async def temp_checker(ctx: Context, sender: str, msg: TempRequest):
    ctx.logger.info(f"Received message from {sender}")
    try:
        temp_output = get_temp(msg.city)
        print(temp_output)
        request_id = str(uuid.uuid4())
        conn_types = []
        # options = []
        # data = bytes(json.loads(temp_output))
        temp_c = str(temp_output['current']['temp_c'])
        print(temp_c)
        # Find the index of "temp_c" in the JSON data
        # index_temp_c = temp_output.find('"temp_c"')

        # Find the start and end of the value of "temp_c"
        # start_temp_c = temp_output.find(':', index_temp_c) + 1
        # end_temp_c = temp_output.find(',', start_temp_c)

        # Extract the "temp_c" value as a string
        # temp_c_str = temp_output[start_temp_c:end_temp_c].strip()
        # for idx, ev_station in enumerate(temp_output):
        #     for conn in ev_station["Connections"]:
        #         conn_types.append(conn["ConnectionType"]["Title"])
        #         conn_type_str = ", ".join(conn_types)
        #         option = f"""● EV charger: {ev_station['AddressInfo']['Title']} , located {round(ev_station['AddressInfo']['Distance'], 2)} miles from your location\n● Usage cost {ev_station['UsageCost']};\n● Type - {conn_type_str}"""

            # options.append(KeyValue(key=idx, value=option))
        # options.insert(0, temp_c)
        await ctx.send(
            sender,
            UAgentResponse(
                mytemp=temp_c,
                type=UAgentResponseType.SELECT_FROM_OPTIONS,
                request_id=request_id,
            ),
        )
    except Exception as exc:
        ctx.logger.error(exc)
        await ctx.send(
            sender, UAgentResponse(message=str(exc), type=UAgentResponseType.ERROR)
        )


agent.include(temp_check_protocol)
